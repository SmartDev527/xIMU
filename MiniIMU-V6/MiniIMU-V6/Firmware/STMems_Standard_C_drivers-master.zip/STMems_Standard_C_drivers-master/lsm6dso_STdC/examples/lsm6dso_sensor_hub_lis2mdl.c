/*
 ******************************************************************************
 * @file    sensor_hub_fifo_lis2mdl.c
 * @author  Sensor Solutions Software Team
 * @brief   This file show the simplest way to read LIS2MDL mag
 *          connected to LSM6DSO I2C master interface (with FIFO support).
 *
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */

/*
 * This example was developed using the following STMicroelectronics
 * evaluation boards:
 *
 * - STEVAL_MKI109V3 + STEVAL-MKI196V1 + STEVAL-MKI181V1
 * - NUCLEO_F401RE + X_NUCLEO_IKS01A3
 * - DISCOVERY_SPC584B + STEVAL-MKI196V1 + STEVAL-MKI181V1
 *
 * Used interfaces:
 *
 * STEVAL_MKI109V3    - Host side:   USB (Virtual COM)
 *                    - Sensor side: SPI(Default) / I2C(supported)
 *
 * NUCLEO_STM32F401RE - Host side: UART(COM) to USB bridge
 *                    - I2C(Default) / SPI(supported)
 *
 * DISCOVERY_SPC584B  - Host side: UART(COM) to USB bridge
 *                    - Sensor side: I2C(Default) / SPI(supported)
 *
 * If you need to run this example on a different hardware platform a
 * modification of the functions: `platform_write`, `platform_read`,
 * `tx_com` and 'platform_init' is required.
 *
 */

/* STMicroelectronics evaluation boards definition
 *
 * Please uncomment ONLY the evaluation boards in use.
 * If a different hardware is used please comment all
 * following target board and redefine yours.
 */

//#define STEVAL_MKI109V3  /* little endian */
//#define NUCLEO_F401RE    /* little endian */
//#define SPC584B_DIS      /* big endian */

/* ATTENTION: By default the driver is little endian. If you need switch
 *            to big endian please see "Endianness definitions" in the
 *            header file of the driver (_reg.h).
 */

#if defined(STEVAL_MKI109V3)
/* MKI109V3: Define communication interface */
#define SENSOR_BUS hspi2
/* MKI109V3: Vdd and Vddio power supply values */
#define PWM_3V3 915

#elif defined(NUCLEO_F401RE)
/* NUCLEO_F401RE: Define communication interface */
#define SENSOR_BUS hi2c1

#elif defined(SPC584B_DIS)
/* DISCOVERY_SPC584B: Define communication interface */
#define SENSOR_BUS I2CD1

#endif

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include <stdio.h>
#include "lsm6dso_reg.h"
#include "lis2mdl_reg.h"

#if defined(NUCLEO_F401RE)
#include "stm32f4xx_hal.h"
#include "usart.h"
#include "gpio.h"
#include "i2c.h"

#elif defined(STEVAL_MKI109V3)
#include "stm32f4xx_hal.h"
#include "usbd_cdc_if.h"
#include "gpio.h"
#include "spi.h"
#include "tim.h"

#elif defined(SPC584B_DIS)
#include "components.h"
#endif

typedef union {
  int16_t i16bit[3];
  uint8_t u8bit[6];
} axis3bit16_t;

/* Private macro -------------------------------------------------------------*/
#define    BOOT_TIME      10
#define TX_BUF_DIM      1000

/* Private variables ---------------------------------------------------------*/
static uint8_t tx_buffer[TX_BUF_DIM];

static stmdev_ctx_t ag_ctx;
static stmdev_ctx_t mag_ctx;

static float_t acceleration_mg[3];
static float_t angular_rate_mdps[3];
static float_t magnetic_mG[3];

/* Extern variables ----------------------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

static int32_t lsm6dso_write_lis2mdl_cx(void *ctx, uint8_t reg,
                                        const uint8_t *data, uint16_t len);
static int32_t lsm6dso_read_lis2mdl_cx(void *ctx, uint8_t reg,
                                       uint8_t *data, uint16_t len);

/*
 *   WARNING:
 *   Functions declare in this section are defined at the end of this file
 *   and are strictly related to the hardware platform used.
 *
 */
static int32_t platform_write(void *handle, uint8_t reg, const uint8_t *bufp,
                              uint16_t len);
static int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp,
                             uint16_t len);
static void tx_com( uint8_t *tx_buffer, uint16_t len );
static void platform_delay(uint32_t ms);
static void platform_init(void);

/* Main Example --------------------------------------------------------------*/

/*
 * Main Example
 *
 * Configure low level function to access to external device
 * Check if LIS2MDL connected to Sensor Hub
 * Configure lis2mdl in CONTINUOUS_MODE with 20 ODR
 * Configure Sensor Hub to read one slave with XL trigger
 * Set FIFO watermark
 * Set FIFO mode to Stream mode
 * Enable FIFO batching of Slave0 + ACC + Gyro samples
 * Poll for FIFO watermark interrupt and read samples
 */
void lsm6dso_sensor_hub_fifo_lis2mdl(void)
{
  uint8_t whoamI, rst, wtm_flag;
  lsm6dso_sh_cfg_read_t sh_cfg_read;
  lsm6dso_pin_int1_route_t int1_route;
  axis3bit16_t data_raw_magnetic;
  axis3bit16_t data_raw_acceleration;
  axis3bit16_t data_raw_angular_rate;
  axis3bit16_t dummy;
  /* Initialize lsm6dso driver interface */
  ag_ctx.write_reg = platform_write;
  ag_ctx.read_reg = platform_read;
  ag_ctx.handle = &SENSOR_BUS;
  /* Initialize lis2mdl driver interface */
  mag_ctx.read_reg = lsm6dso_read_lis2mdl_cx;
  mag_ctx.write_reg = lsm6dso_write_lis2mdl_cx;
  mag_ctx.handle = &SENSOR_BUS;
  /* Init test platform */
  platform_init();
  /* Wait sensor boot time */
  platform_delay(BOOT_TIME);
  /* Check Connected devices. */
  /* Check lsm6dso ID. */
  lsm6dso_device_id_get(&ag_ctx, &whoamI);

  if (whoamI != LSM6DSO_ID)
    while (1);

  /* Restore default configuration. */
  lsm6dso_reset_set(&ag_ctx, PROPERTY_ENABLE);

  do {
    lsm6dso_reset_get(&ag_ctx, &rst);
  } while (rst);

  /* Disable I3C interface.*/
  lsm6dso_i3c_disable_set(&ag_ctx, LSM6DSO_I3C_DISABLE);
  /* Some hardware require to enable pull up on master I2C interface. */
  //lsm6dso_sh_pin_mode_set(&ag_ctx, LSM6DSO_INTERNAL_PULL_UP);
  /* Check if LIS2MDL connected to Sensor Hub. */
  lis2mdl_device_id_get(&mag_ctx, &whoamI);

  if (whoamI != LIS2MDL_ID)
    while (1);

  /* Configure LIS2MDL. */
  lis2mdl_block_data_update_set(&mag_ctx, PROPERTY_ENABLE);
  lis2mdl_offset_temp_comp_set(&mag_ctx, PROPERTY_ENABLE);
  lis2mdl_operating_mode_set(&mag_ctx, LIS2MDL_CONTINUOUS_MODE);
  lis2mdl_data_rate_set(&mag_ctx, LIS2MDL_ODR_20Hz);
  /*Configure LSM6DSO FIFO.
   *
   * Set FIFO watermark (number of unread sensor data TAG + 6 bytes
   * stored in FIFO) to 15 samples. 5 * (Acc + Gyro + Mag)
   */
  lsm6dso_fifo_watermark_set(&ag_ctx, 15);
  /* Set FIFO mode to Stream mode (aka Continuous Mode). */
  lsm6dso_fifo_mode_set(&ag_ctx, LSM6DSO_STREAM_MODE);
  /* Enable latched interrupt notification. */
  lsm6dso_int_notification_set(&ag_ctx, LSM6DSO_ALL_INT_LATCHED);
  /* Enable drdy 75 us pulse: uncomment if interrupt must be pulsed. */
  //lsm6dso_data_ready_mode_set(&ag_ctx, LSM6DSO_DRDY_PULSED);
  /* FIFO watermark interrupt routed on INT1 pin.
   * Remember that INT1 pin is used by sensor to switch in I3C mode.
   */
  lsm6dso_pin_int1_route_get(&ag_ctx, &int1_route);
  int1_route.fifo_th = PROPERTY_ENABLE;
  lsm6dso_pin_int1_route_set(&ag_ctx, int1_route);
  /* Enable FIFO batching of Slave0.
   * ODR batching is 13 Hz.
   */
  lsm6dso_sh_batch_slave_set(&ag_ctx, 0, PROPERTY_ENABLE);
  lsm6dso_sh_data_rate_set(&ag_ctx, LSM6DSO_SH_ODR_13Hz);
  /* Set FIFO batch XL/Gyro ODR to 12.5Hz. */
  lsm6dso_fifo_xl_batch_set(&ag_ctx, LSM6DSO_XL_BATCHED_AT_12Hz5);
  lsm6dso_fifo_gy_batch_set(&ag_ctx, LSM6DSO_GY_BATCHED_AT_12Hz5);
  /* Prepare sensor hub to read data from external Slave0 continuously
   * in order to store data in FIFO.
   */
  sh_cfg_read.slv_add = (LIS2MDL_I2C_ADD & 0xFEU) >>
                        1; /* 7bit I2C address */
  sh_cfg_read.slv_subadd = LIS2MDL_OUTX_L_REG;
  sh_cfg_read.slv_len = 6;
  lsm6dso_sh_slv_cfg_read(&ag_ctx, 0, &sh_cfg_read);
  /* Configure Sensor Hub to read one slave. */
  lsm6dso_sh_slave_connected_set(&ag_ctx, LSM6DSO_SLV_0);
  /* Enable I2C Master. */
  lsm6dso_sh_master_set(&ag_ctx, PROPERTY_ENABLE);
  /* Configure LSM6DSO. */
  lsm6dso_xl_full_scale_set(&ag_ctx, LSM6DSO_2g);
  lsm6dso_gy_full_scale_set(&ag_ctx, LSM6DSO_2000dps);
  lsm6dso_block_data_update_set(&ag_ctx, PROPERTY_ENABLE);
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_12Hz5);
  lsm6dso_gy_data_rate_set(&ag_ctx, LSM6DSO_GY_ODR_12Hz5);

  while (1) {
    uint16_t num = 0;
    lsm6dso_fifo_tag_t reg_tag;
    /* Read watermark flag. */
    lsm6dso_fifo_wtm_flag_get(&ag_ctx, &wtm_flag);

    if ( wtm_flag ) {
      /* Read number of samples in FIFO. */
      lsm6dso_fifo_data_level_get(&ag_ctx, &num);

      while (num--) {
        /* Read FIFO tag. */
        lsm6dso_fifo_sensor_tag_get(&ag_ctx, &reg_tag);

        switch (reg_tag) {
          case LSM6DSO_XL_NC_TAG:
            memset(data_raw_acceleration.u8bit, 0x00, 3 * sizeof(int16_t));
            lsm6dso_fifo_out_raw_get(&ag_ctx, data_raw_acceleration.u8bit);
            acceleration_mg[0] = lsm6dso_from_fs2_to_mg(
                                   data_raw_acceleration.i16bit[0]);
            acceleration_mg[1] = lsm6dso_from_fs2_to_mg(
                                   data_raw_acceleration.i16bit[1]);
            acceleration_mg[2] = lsm6dso_from_fs2_to_mg(
                                   data_raw_acceleration.i16bit[2]);
            snprintf((char *)tx_buffer, sizeof(tx_buffer),
                     "Acceleration [mg]:%4.2f\t%4.2f\t%4.2f\r\n",
                     acceleration_mg[0],
                     acceleration_mg[1],
                     acceleration_mg[2] );
            tx_com(tx_buffer, strlen((char const *)tx_buffer));
            break;

          case LSM6DSO_GYRO_NC_TAG:
            memset(data_raw_angular_rate.u8bit, 0x00, 3 * sizeof(int16_t));
            lsm6dso_fifo_out_raw_get(&ag_ctx, data_raw_angular_rate.u8bit);
            angular_rate_mdps[0] = lsm6dso_from_fs2000_to_mdps(
                                     data_raw_angular_rate.i16bit[0]);
            angular_rate_mdps[1] = lsm6dso_from_fs2000_to_mdps(
                                     data_raw_angular_rate.i16bit[1]);
            angular_rate_mdps[2] = lsm6dso_from_fs2000_to_mdps(
                                     data_raw_angular_rate.i16bit[2]);
            snprintf((char *)tx_buffer, sizeof(tx_buffer),
                     "Angular rate [mdps]:%4.2f\t%4.2f\t%4.2f\r\n",
                     angular_rate_mdps[0],
                     angular_rate_mdps[1],
                     angular_rate_mdps[2]);
            tx_com(tx_buffer, strlen((char const *)tx_buffer));
            break;

          case LSM6DSO_SENSORHUB_SLAVE0_TAG:
            memset(data_raw_magnetic.u8bit, 0x00, 3 * sizeof(int16_t));
            lsm6dso_fifo_out_raw_get(&ag_ctx, data_raw_magnetic.u8bit);
            magnetic_mG[0] = lis2mdl_from_lsb_to_mgauss(
                               data_raw_magnetic.i16bit[0]);
            magnetic_mG[1] = lis2mdl_from_lsb_to_mgauss(
                               data_raw_magnetic.i16bit[1]);
            magnetic_mG[2] = lis2mdl_from_lsb_to_mgauss(
                               data_raw_magnetic.i16bit[2]);
            snprintf((char *)tx_buffer, sizeof(tx_buffer), "Mag [mG]:%4.2f\t%4.2f\t%4.2f\r\n",
                     magnetic_mG[0],
                     magnetic_mG[1],
                     magnetic_mG[2]);
            tx_com(tx_buffer, strlen((char const *)tx_buffer));
            break;

          default:
            /* Flush unused samples. */
            memset(dummy.u8bit, 0x00, 3 * sizeof(int16_t));
            lsm6dso_fifo_out_raw_get(&ag_ctx, dummy.u8bit);
            break;
        }
      }
    }
  }
}

/*
 * @brief  Write generic device register (platform dependent)
 *
 * @param  handle    customizable argument. In this examples is used in
 *                   order to select the correct sensor bus handler.
 * @param  reg       register to write
 * @param  bufp      pointer to data to write in register reg
 * @param  len       number of consecutive register to write
 *
 */
static int32_t platform_write(void *handle, uint8_t reg, const uint8_t *bufp,
                              uint16_t len)
{
#if defined(NUCLEO_F401RE)
  HAL_I2C_Mem_Write(handle, LSM6DSO_I2C_ADD_H, reg,
                    I2C_MEMADD_SIZE_8BIT, (uint8_t*) bufp, len, 1000);
#elif defined(STEVAL_MKI109V3)
  HAL_GPIO_WritePin(CS_up_GPIO_Port, CS_up_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(handle, &reg, 1, 1000);
  HAL_SPI_Transmit(handle, (uint8_t*) bufp, len, 1000);
  HAL_GPIO_WritePin(CS_up_GPIO_Port, CS_up_Pin, GPIO_PIN_SET);
#elif defined(SPC584B_DIS)
  i2c_lld_write(handle,  LSM6DSO_I2C_ADD_H & 0xFE, reg, (uint8_t*) bufp, len);
#endif
  return 0;
}

/*
 * @brief  Read generic device register (platform dependent)
 *
 * @param  handle    customizable argument. In this examples is used in
 *                   order to select the correct sensor bus handler.
 * @param  reg       register to read
 * @param  bufp      pointer to buffer that store the data read
 * @param  len       number of consecutive register to read
 *
 */
static int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp,
                             uint16_t len)
{
#if defined(NUCLEO_F401RE)
  HAL_I2C_Mem_Read(handle, LSM6DSO_I2C_ADD_H, reg,
                   I2C_MEMADD_SIZE_8BIT, bufp, len, 1000);
#elif defined(STEVAL_MKI109V3)
  reg |= 0x80;
  HAL_GPIO_WritePin(CS_up_GPIO_Port, CS_up_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(handle, &reg, 1, 1000);
  HAL_SPI_Receive(handle, bufp, len, 1000);
  HAL_GPIO_WritePin(CS_up_GPIO_Port, CS_up_Pin, GPIO_PIN_SET);
#elif defined(SPC584B_DIS)
  i2c_lld_read(handle, LSM6DSO_I2C_ADD_H & 0xFE, reg, bufp, len);
#endif
  return 0;
}

/*
 * @brief  Send buffer to console (platform dependent)
 *
 * @param  tx_buffer     buffer to transmit
 * @param  len           number of byte to send
 *
 */
static void tx_com(uint8_t *tx_buffer, uint16_t len)
{
#if defined(NUCLEO_F401RE)
  HAL_UART_Transmit(&huart2, tx_buffer, len, 1000);
#elif defined(STEVAL_MKI109V3)
  CDC_Transmit_FS(tx_buffer, len);
#elif defined(SPC584B_DIS)
  sd_lld_write(&SD2, tx_buffer, len);
#endif
}

/*
 * @brief  platform specific delay (platform dependent)
 *
 * @param  ms        delay in ms
 *
 */
static void platform_delay(uint32_t ms)
{
#if defined(NUCLEO_F401RE) | defined(STEVAL_MKI109V3)
  HAL_Delay(ms);
#elif defined(SPC584B_DIS)
  osalThreadDelayMilliseconds(ms);
#endif
}

/*
 * @brief  platform specific initialization (platform dependent)
 */
static void platform_init(void)
{
#if defined(STEVAL_MKI109V3)
  TIM3->CCR1 = PWM_3V3;
  TIM3->CCR2 = PWM_3V3;
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_Delay(1000);
#endif
}

/*
 * @brief  Write lsm2mdl device register (used by configuration functions)
 *
 * @param  handle    customizable argument. In this examples is used in
 *                   order to select the correct sensor bus handler.
 * @param  reg       register to write
 * @param  bufp      pointer to data to write in register reg
 * @param  len       number of consecutive register to write
 *
 */
static int32_t lsm6dso_write_lis2mdl_cx(void *ctx, uint8_t reg,
                                        const uint8_t *data, uint16_t len)
{
  axis3bit16_t data_raw_acceleration;
  int32_t ret;
  uint8_t drdy;
  lsm6dso_status_master_t master_status;
  lsm6dso_sh_cfg_write_t sh_cfg_write;
  /* Configure Sensor Hub to read LIS2MDL. */
  sh_cfg_write.slv0_add = (LIS2MDL_I2C_ADD & 0xFEU) >>
                          1; /* 7bit I2C address */
  sh_cfg_write.slv0_subadd = reg,
  sh_cfg_write.slv0_data = *data,
  ret = lsm6dso_sh_cfg_write(&ag_ctx, &sh_cfg_write);
  /* Disable accelerometer. */
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_OFF);
  /* Enable I2C Master. */
  lsm6dso_sh_master_set(&ag_ctx, PROPERTY_ENABLE);
  /* Enable accelerometer to trigger Sensor Hub operation. */
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_104Hz);
  /* Wait Sensor Hub operation flag set. */
  lsm6dso_acceleration_raw_get(&ag_ctx, data_raw_acceleration.i16bit);

  do {
    HAL_Delay(20);
    lsm6dso_xl_flag_data_ready_get(&ag_ctx, &drdy);
  } while (!drdy);

  do {
    HAL_Delay(20);
    lsm6dso_sh_status_get(&ag_ctx, &master_status);
  } while (!master_status.sens_hub_endop);

  /* Disable I2C master and XL (trigger). */
  lsm6dso_sh_master_set(&ag_ctx, PROPERTY_DISABLE);
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_OFF);
  return ret;
}

/*
 * @brief  Read lsm2mdl device register (used by configuration functions)
 *
 * @param  handle    customizable argument. In this examples is used in
 *                   order to select the correct sensor bus handler.
 * @param  reg       register to read
 * @param  bufp      pointer to buffer that store the data read
 * @param  len       number of consecutive register to read
 *
 */
static int32_t lsm6dso_read_lis2mdl_cx(void *ctx, uint8_t reg,
                                       uint8_t *data, uint16_t len)
{
  lsm6dso_sh_cfg_read_t sh_cfg_read;
  axis3bit16_t data_raw_acceleration;
  int32_t ret;
  uint8_t drdy;
  lsm6dso_status_master_t master_status;
  /* Disable accelerometer. */
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_OFF);
  /* Configure Sensor Hub to read LIS2MDL. */
  sh_cfg_read.slv_add = (LIS2MDL_I2C_ADD & 0xFEU) >>
                        1; /* 7bit I2C address */
  sh_cfg_read.slv_subadd = reg;
  sh_cfg_read.slv_len = len;
  ret = lsm6dso_sh_slv_cfg_read(&ag_ctx, 0, &sh_cfg_read);
  lsm6dso_sh_slave_connected_set(&ag_ctx, LSM6DSO_SLV_0);
  /* Enable I2C Master and I2C master. */
  lsm6dso_sh_master_set(&ag_ctx, PROPERTY_ENABLE);
  /* Enable accelerometer to trigger Sensor Hub operation. */
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_104Hz);
  /* Wait Sensor Hub operation flag set. */
  lsm6dso_acceleration_raw_get(&ag_ctx, data_raw_acceleration.i16bit);

  do {
    HAL_Delay(20);
    lsm6dso_xl_flag_data_ready_get(&ag_ctx, &drdy);
  } while (!drdy);

  do {
    //HAL_Delay(20);
    lsm6dso_sh_status_get(&ag_ctx, &master_status);
  } while (!master_status.sens_hub_endop);

  /* Disable I2C master and XL(trigger). */
  lsm6dso_sh_master_set(&ag_ctx, PROPERTY_DISABLE);
  lsm6dso_xl_data_rate_set(&ag_ctx, LSM6DSO_XL_ODR_OFF);
  /* Read SensorHub registers. */
  lsm6dso_sh_read_data_raw_get(&ag_ctx, data, len);
  return ret;
}
