# Examples

This folder contains application examples. The examples refer to following boards but, since the drivers are platform independent, they can be easily ported to any other platform: 

- STEVAL-MKI109V3 (https://www.st.com/en/evaluation-tools/steval-mki109v3.html)
- NUCLEO-F401RE (https://www.st.com/en/microcontrollers-microprocessors/stm32f401re.html)
- DISCOVERY-SPC584B (https://www.st.com/en/evaluation-tools/spc584b-dis.html)

## Self Test (ST)

Run the device Self Test procedure:

  - lis2mdl_self_test.c

## Read data

Read magnetometer and temperature sensor data in both polling and drdy mode:

  - lis2mdl_read_data_polling.c
  - lis2mdl_read_data_single.c
  - lis2mdl_read_data_int.c

Read magnetometer sensor data when mag threshold crossing condition is verified:

  - lis2mdl_int_conf.c

Read magnetometer sensor data and apply hard iron correction:

  - lis2mdl_hard_iron.c
